import Mesh from './mesh.js'
import * as vec3 from '../lib/vec3.js'
import * as vec4 from "../lib/vec4.js";
import * as vec2 from "../lib/vec2.js";
import * as mat4 from '../lib/mat4.js';


// A renderer is more high level than a rasterizer.
// He decides which geometric primitives have to be rasterized at all.
// Deciding this has to do with scene setup, visibility detection, culling and so on.

export default {

    rasterizer: null,
    scale: 40,

    init: function (rasterizer) {
        this.rasterizer = rasterizer
    },

    transformPosition: function (out, position, time, isOuter = false) {

        const transformedPosition = vec4.zero();
        const translationMatrix = mat4.identity();
        const scaleMatrix = mat4.identity();
        const projectionMatrix = mat4.zero();
        const rotationMatrix1 = mat4.identity();
        const rotationMatrix2 = mat4.identity();
        const combinedRotation = mat4.identity();


        //mat4.scale(scaleMatrix, [-2, -2, -2]);

        // ModelView Matrix
        if (isOuter) {
            mat4.translation(translationMatrix, [0, 0, -3]);
            mat4.scale(scaleMatrix, [2, 2, 2]);
        } else {
            mat4.translation(translationMatrix, [0, 0, -10]);
            mat4.scale(scaleMatrix, [-4, -4, -4]);
        }

        //Aufgabe 6.5
        //Projection Matrix
        mat4.perspective(projectionMatrix);

        //Aufgabe 6.1 + 6.2
        const radian1 = (time * 0.00095)
        const radian2 = (time * 0.00050)
        mat4.rotation(rotationMatrix1, [1, 0, 0], isOuter ? -radian2 : radian1);
        mat4.rotation(rotationMatrix2, [0, 1, 0], isOuter ? -radian1 : radian2);
        mat4.multiply(combinedRotation, rotationMatrix1, rotationMatrix2);

        //Combine all transformations into a single matrix
        const combinedMatrix = mat4.identity();
        mat4.multiply(combinedMatrix, scaleMatrix, combinedMatrix);
        mat4.multiply(combinedMatrix, combinedRotation, combinedMatrix);
        mat4.multiply(combinedMatrix, translationMatrix, combinedMatrix);
        mat4.multiply(combinedMatrix, projectionMatrix, combinedMatrix);

        mat4.transformVec4(transformedPosition, combinedMatrix, [...position, 1.0]);

        // Devide by w
        transformedPosition[0] /= transformedPosition[3];
        transformedPosition[1] /= transformedPosition[3];
        transformedPosition[2] /= transformedPosition[3];

        // Viewport Transform
        const canvasCenterX = (this.rasterizer.canvasWidth / this.rasterizer.canvasPixelSize) / 2;
        const canvasCenterY = (this.rasterizer.canvasHeight / this.rasterizer.canvasPixelSize) / 2;

        out[0] = canvasCenterX + transformedPosition[0] * canvasCenterX;
        out[1] = canvasCenterY - transformedPosition[1] * canvasCenterY;
        out[2] = transformedPosition[2];
    },

    draw: function (meshes = [], time = 0, isOuter = false) {
        console.assert(this.rasterizer !== null);

        for (let mesh of meshes) {

            // the renderer will not change the contents of the attributes
            // so its ok we access them here (this avoids a lot of get/set boilerplate)
            let positions = mesh._positions;
            let indices = mesh._indices;
            let colors = mesh._colors;

            // detect if individual vertex color are defined
            let multipleColors = colors.length > 1;
            //console.log("color length: ", colors[0].length);
            let singleColor = colors[0];

            // temporary variable for vertex transformations
            let transformedA = vec3.zero();

            switch (mesh._primitiveType) {
                case Mesh.POINT:
                    for (let i = 0; i < indices.length; i++) {
                        let vi = indices[i];
                        this.transformPosition(transformedA, positions[vi], time, isOuter);
                        this.rasterizer.setPixel(
                            transformedA[0],
                            transformedA[1],
                            multipleColors ? colors[vi] : singleColor
                        );
                    }
                    break;

                case Mesh.LINE:
                    for (let i = 0; i < indices.length; i += 2) {
                        let A = indices[i];
                        let B = indices[i + 1];

                        let startPoint = vec3.zero();
                        let endPoint = vec3.zero();

                        this.transformPosition(startPoint, positions[A], time, isOuter);
                        this.transformPosition(endPoint, positions[B], time, isOuter);

                        for (let t = 0; t <= 1; t += 1 / this.scale) {
                            vec3.lerp(transformedA, positions[A], positions[B], t);
                            this.transformPosition(transformedA, transformedA, time, isOuter);

                            this.rasterizer.setPixel(
                                transformedA[0],
                                transformedA[1],
                                multipleColors
                                    ? vec4.lerp([], colors[A], colors[B], t)
                                    : singleColor
                            );
                        }
                    }
                    break;

                case Mesh.TRIANGLE:
                    for (let i = 0; i < indices.length; i += 3) {
                        let A = indices[i];
                        let B = indices[i + 1];
                        let C = indices[i + 2];

                        let transformedA = vec3.zero();
                        let transformedB = vec3.zero();
                        let transformedC = vec3.zero();

                        this.transformPosition(transformedA, positions[A], time, isOuter);
                        const a = [transformedA[0], transformedA[1]];
                        const colorA = multipleColors ? colors[A] : singleColor;

                        this.transformPosition(transformedB, positions[B], time, isOuter);
                        const b = [transformedB[0], transformedB[1]];
                        const colorB = multipleColors ? colors[B] : singleColor;

                        this.transformPosition(transformedC, positions[C], time, isOuter);
                        const c = [transformedC[0], transformedC[1]];
                        const colorC = multipleColors ? colors[C] : singleColor;

                        // Aufgabe 6.4
                        const edgeVecA = vec3.zero();
                        const edgeVecB = vec3.zero();

                        vec3.subtract(edgeVecA, transformedB, transformedA);
                        vec3.subtract(edgeVecB, transformedC, transformedA);

                        const normal = vec3.zero();
                        vec3.cross(normal, edgeVecA, edgeVecB);

                        if (normal[2] <= 0) {
                            continue;
                        }

                        const xmin = Math.min(a[0], b[0], c[0]);
                        const xmax = Math.max(a[0], b[0], c[0]);
                        const ymin = Math.min(a[1], b[1], c[1]);
                        const ymax = Math.max(a[1], b[1], c[1]);

                        const winding = vec2.signedTriangleArea(a, b, c) > 0 ? 1 : -1;

                        for (let y = Math.ceil(ymin); y <= Math.floor(ymax); y++) {
                            for (let x = Math.ceil(xmin); x <= Math.floor(xmax); x++) {
                                const p = [x, y];

                                if (winding * vec2.signedTriangleArea(p, a, b) >= 0 &&
                                    winding * vec2.signedTriangleArea(p, b, c) >= 0 &&
                                    winding * vec2.signedTriangleArea(p, c, a) >= 0) {

                                    const denominator = vec2.signedTriangleArea(a, b, c);
                                    const alpha = vec2.signedTriangleArea(p, b, c) / denominator;
                                    const beta = vec2.signedTriangleArea(p, c, a) / denominator;
                                    const gamma = 1 - alpha - beta;

                                    const interpolatedColor = [
                                        alpha * colorA[0] + beta * colorB[0] + gamma * colorC[0],
                                        alpha * colorA[1] + beta * colorB[1] + gamma * colorC[1],
                                        alpha * colorA[2] + beta * colorB[2] + gamma * colorC[2],
                                        alpha * colorA[3] + beta * colorB[3] + gamma * colorC[3],
                                    ];

                                    this.rasterizer.setPixel(x, y, interpolatedColor);
                                }
                            }
                        }
                    }
                    break;
            }
        }
    },


    //Aufgabe 6.3
    clear: function (color = [255, 255, 255, 255]) {
        const data = this.rasterizer.framebuffer.data;
        const width = this.rasterizer.canvasWidth;
        const height = this.rasterizer.canvasHeight;

        for (let y = 0; y < height; y++) {
            for (let x = 0; x < width; x++) {
                const index = (y * width + x) * 4;
                data[index] = color[0];
                data[index + 1] = color[1];
                data[index + 2] = color[2];
                data[index + 3] = color[3];
            }
        }
    }

}